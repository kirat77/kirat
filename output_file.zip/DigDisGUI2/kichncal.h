#ifndef KICHNCAL_H
#define KICHNCAL_H

#include <QDialog>

namespace Ui {
class kichncal;
}

class kichncal : public QDialog
{
    Q_OBJECT

public:
    explicit kichncal(QWidget *parent = nullptr);
    ~kichncal();

private:
    Ui::kichncal *ui;
};

#endif // KICHNCAL_H
