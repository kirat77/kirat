#include "kichncal.h"
#include "ui_kichncal.h"

kichncal::kichncal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::kichncal)
{
    ui->setupUi(this);
}

kichncal::~kichncal()
{
    delete ui;
}
