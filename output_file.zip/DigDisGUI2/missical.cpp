#include "missical.h"
#include "ui_missical.h"

Missical::Missical(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Missical)
{
    ui->setupUi(this);
}

Missical::~Missical()
{
    delete ui;
}
