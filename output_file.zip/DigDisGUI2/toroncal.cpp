#include "toroncal.h"
#include "ui_toroncal.h"

toroncal::toroncal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::toroncal)
{
    ui->setupUi(this);
}

toroncal::~toroncal()
{
    delete ui;
}
